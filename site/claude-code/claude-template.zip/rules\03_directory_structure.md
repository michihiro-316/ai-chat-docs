# ディレクトリ構造（固定）

本フェーズでは以下を正式構成とする。

python/
├─ backend.py
├─ front.html
├─ script.js
└─ requirements.txt

肥大化した場合のみ、合意の上で分割する。
