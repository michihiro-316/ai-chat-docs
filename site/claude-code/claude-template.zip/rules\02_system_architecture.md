# システム構成（アーキテクチャ）— **フロントもバックエンドも Cloud Run**

本ドキュメントは、**フロントエンド（画面配信）もバックエンド（API）も同じく Cloud Run 上で提供する**前提で、
システム全体の最小アーキテクチャを定義する。

詳細実装ルールは以下を優先：
- 境界仕様：`04_boundary_policy.md`
- セキュリティ：`05_security_notes.md`
- Cloud Run運用：`06_cloudrun_ops.md`

---

## 1. 構成パターン（推奨）

### 推奨：単一 Cloud Run サービス（PoC向け）
1つの Cloud Run サービスで **画面（静的アセット配信）** と **API** を同居させる。

- `/` : 画面（`front.html`）
- `/static/*` : JS/CSS など（`script.js` 等）
- `/api/*` : API（例：`/api/health`, `/api/chat`）

**メリット**：構成が単純・CORSが不要・運用が軽い  
**注意**：責務分離は「URLとディレクトリ構造」で担保する（コード混在を防ぐ）

### 参考：分割 Cloud Run サービス（本番拡張向け）
- Cloud Run (Frontend): 画面配信のみ
- Cloud Run (API): APIのみ

**メリット**：スケール/権限/デプロイを分離しやすい  
**デメリット**：CORSやドメイン設計が増え、PoCでは過剰になりがち

---

## 2. コンポーネント概要（単一 Cloud Run 前提）

### UI（ブラウザで動く）
- `front.html`：画面・DOM。**ロジックを持たない**（UI構造と最小のイベントフックのみ）
- `script.js`：振る舞い・状態・API通信・認証ハンドリング

**禁止**：`front.html` に JS ロジックを戻す（混在させる）こと。

### Cloud Run アプリ（サーバ側）
- 画面配信（`front.html` / 静的ファイル）
- API提供（`/api/*`）
- 外部AI API などへの接続（必要に応じて）

**重要**：
- 外部APIキー等の秘密情報は **環境変数** で管理し、フロントへ渡さない
- ログに個人情報/機密情報を出さない（詳細は `05_security_notes.md`）

### データストア（任意）
- ユーザー設定（例：ダークモード、フォントサイズ）などの永続化が必要な場合にのみ導入
- 候補：Firebase（Realtime Database / Firestore）等
- PoCフェーズでは **「保存しない」** を優先し、要件確定後に導入する

---

## 3. データフロー（基本）

```text
[Browser]
  front.html  (UI)
    |
    v
  script.js   (state / auth / fetch)
    |
    | HTTPS (same origin, JSON)
    v
[Cloud Run (single service)]
  GET  /            -> front.html
  GET  /static/*    -> script.js, css, etc
  POST /api/chat    -> server-side logic
  GET  /api/health  -> health check
    |
    | (必要に応じて) 外部AI API / DB
    v
[External Services]
```

- ブラウザは **同一オリジン** で Cloud Run にアクセスする（CORSを避ける）
- 外部サービス接続は Cloud Run 側で行い、認証情報はレスポンスに含めない

---

## 4. 境界（Boundary）と責務分離

境界の「契約」は `04_boundary_policy.md` を唯一の正とする。
本ドキュメントは設計意図のレベルに留め、契約（型/スキーマ/コード）を重複定義しない。

- **UI層**：DOM描画、ユーザー入力
- **Clientロジック層**（script.js）：入力検証、送信、結果描画、状態管理
- **Server層**（Cloud Run）：認可/検証、外部API呼び出し、結果整形、監査可能なログ
- **外部サービス層**：AI API、DB、認証基盤 等

---

## 5. ルーティング規約（単一 Cloud Run）

- UI: `/`（HTML）
- Static: `/static/*`（JS/CSS/画像など）
- API: `/api/*`

**禁止**：
- `/api` 以外のパスで API を生やす（境界が曖昧になる）
- HTMLとJSの責務分離を崩す（`front.html` にロジックを戻す 等）

---

## 6. エラー設計（最小）

- フロントは `try/catch` とタイムアウトを持ち、UIに失敗を表示する
- サーバはエラーを 4xx/5xx に分類し、**内部情報を返さない**
- 具体のエラーフォーマットは境界仕様（`04_boundary_policy.md`）側で定義する

---

## 7. 非ゴール（やらないこと）

PoCのスコープを守るため、以下は「要件が固まるまで」実施しない：
- 複雑な状態管理（SPA化・巨大フレームワーク導入）
- ブラウザから外部AI APIへ直接接続（キー漏洩リスク）
- 保存必須でないデータのDB永続化
- Cloud Run を超える過剰な運用（複雑なネットワーク、過剰な分割 等）

---

## 8. 変更手順（ドキュメントの矛盾防止）

- 境界契約を変える場合：必ず `04_boundary_policy.md` を先に更新
- セキュリティ判断が絡む場合：`05_security_notes.md` を同時更新
- 変更の「理由」は `01_comment_policy.md` の方針に従い最小限で残す
