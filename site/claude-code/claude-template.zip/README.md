# .claude/ (Claude Code project configuration)

- `.claude/CLAUDE.md`: main entry for project memory
- `.claude/rules/*.md`: modular rule files (auto-loaded as project memory)
- `.claude/settings.json`: team-shared Claude Code settings (optional)
- `.claude/settings.local.json`: personal overrides (gitignored)

## Suggested .gitignore
```
.claude/settings.local.json
.claude/.history/
```
